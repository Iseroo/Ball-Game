import json

def makeColumn(map, index):
    return [i[index] for i in map]

def makeRow(map, index):
    return map[index]

global map
map = []


class BlockNode:
    def __init__(self, north, west, south, east, coords) -> None:
        self.north = north
        self.west = west
        self.south = south
        self.east = east
        self.coords = coords
        self.directions = {'north': None, 'south': None, 'east': None, 'west': None}

    def __str__(self) -> str:
        return f'{ "| " if self.west else "  "}{"二" if self.north and self.south else "▔▔" if self.north else "__" if self.south else "  "}{" |" if self.east else "  "}'

    def setup_directions(self, map):
        if self.directions['north'] == None:
            self.find_next('north', makeColumn(map, self.coords[1]))
        if self.directions['south'] == None:
            self.find_next('south', makeColumn(map, self.coords[1]))
        if self.directions['east'] == None:
            self.find_next('east', makeRow(map, self.coords[0]))
        if self.directions['west'] == None:
            self.find_next('west', makeRow(map, self.coords[0]))

    def find_next(self, direction, path):
        if direction == 'north':
           
            if self.directions['north'] == None:
                
                if self.coords[0] == 0:
                    self.directions['north'] = self
                for x in range(self.coords[0], -1, -1):
                    
                    if path[x].north:
                        
                        self.directions['north'] = path[x]
                        break
        elif direction == 'south':
            if self.directions['south'] == None:

                if self.coords[0] == len(path) - 1:
                    self.directions['south'] = self

                for x in range(self.coords[0], len(path)):
                    if path[x].south:
                        self.directions['south'] = path[x]
                        break
        elif direction == 'east':
            if self.directions['east'] == None:


                if self.coords[1] == len(path) - 1:
                    self.directions['east'] = self
                for x in range(self.coords[1], len(path)):
                    if path[x].east:
                        self.directions['east'] = path[x]
                        break
        elif direction == 'west':
            if self.directions['west'] == None:

                if self.coords[1] == 0:
                    self.directions['west'] = self
                for x in range(self.coords[1], -1, -1):
                   
                    if path[x].west:
                        self.directions['west'] = path[x]
                        break                                                            

    def get_next(self, direction):
        return self.directions[direction]




def readmap():
    with open('map.json', 'r') as f:
        data = json.load(f)
        for index, i in enumerate(data):
            temp = []
            for index2, i2 in enumerate(i):

                temp.append(BlockNode(i2['north'], i2['west'], i2['south'], i2['east'], (index, index2)))
            map.append(temp)    



if __name__ == '__main__':
    readmap()
    for i in map:
        for i2 in i:
            i2.setup_directions(map)
    direction = "south"
    coords = (1,4)
    next = map[coords[0]][coords[1]].get_next(direction)
    print(f"from: {map[coords[0]][coords[1]]} ({coords[0]+1},{coords[1]+1}) to direction ({direction}) -> {next} ({next.coords[0]+1},{next.coords[1]+1})")